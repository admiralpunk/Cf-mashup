import React from 'react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import { CustomSelect } from '../ui/Select';
import { Button } from '../ui/Button';
import { UsernameInput } from '../ui/UsernameInput';
import { ContestFormData } from '../../types/mashup';

const CONTEST_TYPES = [
  { value: 'div1_2', label: 'Div. 1 + Div. 2' },
  { value: 'div2', label: 'Div. 2 Only' },
  { value: 'div3', label: 'Div. 3 Only' },
];

export function ContestForm() {
  const [formData, setFormData] = React.useState<ContestFormData>({
    users: [],
    contestType: 'div2',
  });
  const [loading, setLoading] = React.useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500));
      toast.success('Contest generated successfully!');
      // Handle the response here
    } catch (error) {
      toast.error('Failed to generate contest');
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.form
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6 bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg"
      onSubmit={handleSubmit}
    >
      <UsernameInput
        users={formData.users}
        onChange={(users) => setFormData({ ...formData, users })}
      />

      <CustomSelect
        label="Contest Type"
        options={CONTEST_TYPES}
        onChange={(selected) => {
          setFormData({
            ...formData,
            contestType: selected?.value as ContestFormData['contestType'],
          });
        }}
      />

      <Button
        type="submit"
        loading={loading}
        className="w-full"
      >
        Generate Contest
      </Button>
    </motion.form>
  );
}