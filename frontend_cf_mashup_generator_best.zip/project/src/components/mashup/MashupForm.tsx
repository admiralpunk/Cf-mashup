import React from 'react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import { CustomSelect } from '../ui/Select';
import { Button } from '../ui/Button';
import { UsernameInput } from '../ui/UsernameInput';
import { DifficultyInput } from './DifficultyInput';
import { MashupFormData, User, Tag } from '../../types/mashup';

const SAMPLE_TAGS = [
  { id: '1', name: 'dp' },
  { id: '2', name: 'graphs' },
  { id: '3', name: 'implementation' },
  { id: '4', name: 'math' },
  { id: '5', name: 'greedy' },
];

export function MashupForm() {
  const [formData, setFormData] = React.useState<MashupFormData>({
    users: [],
    difficultyRequirements: [{ difficulty: 1200, count: 1 }],
    wantedTags: [],
    unwantedTags: [],
  });
  const [loading, setLoading] = React.useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500));
      toast.success('Mashup generated successfully!');
      // Handle the response here
    } catch (error) {
      toast.error('Failed to generate mashup');
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.form
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6 bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg"
      onSubmit={handleSubmit}
    >
      <UsernameInput
        users={formData.users}
        onChange={(users) => setFormData({ ...formData, users })}
      />

      <DifficultyInput
        requirements={formData.difficultyRequirements}
        onChange={(requirements) => {
          setFormData({ ...formData, difficultyRequirements: requirements });
        }}
      />

      <CustomSelect
        label="Wanted Tags"
        isMulti
        options={SAMPLE_TAGS.map(tag => ({
          value: tag.id,
          label: tag.name,
        }))}
        onChange={(selected) => {
          setFormData({
            ...formData,
            wantedTags: selected.map(option => ({
              id: option.value,
              name: option.label,
            })) as Tag[],
          });
        }}
      />

      <CustomSelect
        label="Unwanted Tags"
        isMulti
        options={SAMPLE_TAGS.map(tag => ({
          value: tag.id,
          label: tag.name,
        }))}
        onChange={(selected) => {
          setFormData({
            ...formData,
            unwantedTags: selected.map(option => ({
              id: option.value,
              name: option.label,
            })) as Tag[],
          });
        }}
      />

      <Button
        type="submit"
        loading={loading}
        className="w-full"
      >
        Generate Mashup
      </Button>
    </motion.form>
  );
}